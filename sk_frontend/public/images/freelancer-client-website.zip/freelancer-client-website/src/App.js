import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Portfolio from './pages/Portfolio';
import FindProjects from './pages/FindProjects';
import Messages from './pages/Messages';
import Earnings from './pages/Earnings';
import Feedback from './pages/Feedback';
import Skills from './pages/Skills';
import Settings from './pages/Settings';
import './App.css';

function App() {
  return (
    <Router>
      <div className="app">
        <Header />
        <div className="main-content">
          <Sidebar />
          <main className="page-content">
            <Switch>
              <Route exact path="/" component={Dashboard} />
              <Route path="/portfolio" component={Portfolio} />
              <Route path="/find-projects" component={FindProjects} />
              <Route path="/messages" component={Messages} />
              <Route path="/earnings" component={Earnings} />
              <Route path="/feedback" component={Feedback} />
              <Route path="/skills" component={Skills} />
              <Route path="/settings" component={Settings} />
            </Switch>
          </main>
        </div>
      </div>
    </Router>
  );
}

export default App;

