import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

function Header() {
  return (
    <header className="header">
      <div className="logo">
        <Link to="/">FreelancePro</Link>
      </div>
      <nav>
        <ul>
          <li><Link to="/messages">Messages</Link></li>
          <li><Link to="/settings">Settings</Link></li>
          <li><button className="logout-button">Logout</button></li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;

