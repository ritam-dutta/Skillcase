import React from 'react';
import { NavLink } from 'react-router-dom';
import './Sidebar.css';

function Sidebar() {
  return (
    <aside className="sidebar">
      <nav>
        <ul>
          <li><NavLink exact to="/" activeClassName="active">Dashboard</NavLink></li>
          <li><NavLink to="/portfolio" activeClassName="active">Portfolio</NavLink></li>
          <li><NavLink to="/find-projects" activeClassName="active">Find Projects</NavLink></li>
          <li><NavLink to="/messages" activeClassName="active">Messages</NavLink></li>
          <li><NavLink to="/earnings" activeClassName="active">Earnings & Withdrawals</NavLink></li>
          <li><NavLink to="/feedback" activeClassName="active">Feedback & Reviews</NavLink></li>
          <li><NavLink to="/skills" activeClassName="active">Skills & Certifications</NavLink></li>
          <li><NavLink to="/settings" activeClassName="active">Settings</NavLink></li>
        </ul>
      </nav>
    </aside>
  );
}

export default Sidebar;

