import React, { useState } from 'react';
import './FindProjects.css';

function FindProjects() {
  const [filters, setFilters] = useState({
    category: '',
    minBudget: '',
    maxBudget: '',
    duration: ''
  });

  const projects = [
    { id: 1, title: 'WordPress Website Development', description: 'Need a custom WordPress theme developed for a corporate website', budget: 2000, duration: '2-4 weeks' },
    { id: 2, title: 'Mobile App UI Design', description: 'Looking for a talented UI designer for a new iOS app', budget: 1500, duration: '1-2 weeks' },
    { id: 3, title: 'E-commerce Platform Integration', description: 'Need help integrating a payment gateway into an existing e-commerce site', budget: 1000, duration: '1 week' },
  ];

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prevFilters => ({ ...prevFilters, [name]: value }));
  };

  return (
    <div className="find-projects">
      <h1>Find Projects</h1>
      <div className="filters">
        <select name="category" onChange={handleFilterChange} value={filters.category}>
          <option value="">All Categories</option>
          <option value="web">Web Development</option>
          <option value="mobile">Mobile Development</option>
          <option value="design">Design</option>
        </select>
        <input
          type="number"
          name="minBudget"
          placeholder="Min Budget"
          onChange={handleFilterChange}
          value={filters.minBudget}
        />
        <input
          type="number"
          name="maxBudget"
          placeholder="Max Budget"
          onChange={handleFilterChange}
          value={filters.maxBudget}
        />
        <select name="duration" onChange={handleFilterChange} value={filters.duration}>
          <option value="">Any Duration</option>
          <option value="short">Less than 1 week</option>
          <option value="medium">1-4 weeks</option>
          <option value="long">More than 1 month</option>
        </select>
      </div>
      <div className="project-list">
        {projects.map((project) => (
          <div key={project.id} className="project-card">
            <h3>{project.title}</h3>
            <p>{project.description}</p>
            <p>Budget: ${project.budget}</p>
            <p>Duration: {project.duration}</p>
            <button className="apply-button">Apply</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FindProjects;

