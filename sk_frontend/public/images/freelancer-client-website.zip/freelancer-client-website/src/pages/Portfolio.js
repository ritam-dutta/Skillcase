import React from 'react';
import './Portfolio.css';

function Portfolio() {
  const projects = [
    { id: 1, title: 'E-commerce Website', image: '/placeholder.svg?height=200&width=300', description: 'A fully responsive e-commerce website', skills: ['React', 'Node.js', 'MongoDB'], clientFeedback: 'Excellent work!', rating: 5 },
    { id: 2, title: 'Mobile App', image: '/placeholder.svg?height=200&width=300', description: 'iOS and Android app for task management', skills: ['React Native', 'Firebase'], clientFeedback: 'Great communication and delivery', rating: 4 },
    { id: 3, title: 'Blog Theme', image: '/placeholder.svg?height=200&width=300', description: 'Custom WordPress theme for a popular blog', skills: ['WordPress', 'PHP', 'JavaScript'], clientFeedback: 'Exceeded expectations', rating: 5 },
  ];

  return (
    <div className="portfolio">
      <h1>Portfolio</h1>
      <div className="project-grid">
        {projects.map((project) => (
          <div key={project.id} className="project-card">
            <img src={project.image} alt={project.title} />
            <h3>{project.title}</h3>
            <p>{project.description}</p>
            <div className="skills">
              {project.skills.map((skill, index) => (
                <span key={index} className="skill">{skill}</span>
              ))}
            </div>
            <div className="feedback">
              <p>Client Feedback: {project.clientFeedback}</p>
              <p>Rating: {project.rating}/5</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Portfolio;

