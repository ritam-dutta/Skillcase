import React, { useState } from 'react';
import './Messages.css';

function Messages() {
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [message, setMessage] = useState('');

  const conversations = [
    { id: 1, name: 'John Doe', avatar: '/placeholder.svg?height=40&width=40', lastMessage: 'Thanks for your work!' },
    { id: 2, name: 'Jane Smith', avatar: '/placeholder.svg?height=40&width=40', lastMessage: 'Can we schedule a call?' },
    { id: 3, name: 'Bob Johnson', avatar: '/placeholder.svg?height=40&width=40', lastMessage: 'The project is coming along nicely.' },
  ];

  const handleSendMessage = (e) => {
    e.preventDefault();
    // In a real app, this would send the message to the backend
    console.log('Sending message:', message);
    setMessage('');
  };

  return (
    <div className="messages">
      <h1>Messages</h1>
      <div className="message-container">
        <div className="conversation-list">
          {conversations.map((conv) => (
            <div
              key={conv.id}
              className={`conversation-item ${selectedConversation?.id === conv.id ? 'active' : ''}`}
              onClick={() => setSelectedConversation(conv)}
            >
              <img src={conv.avatar} alt={conv.name} className="avatar" />
              <div>
                <h3>{conv.name}</h3>
                <p>{conv.lastMessage}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="chat-area">
          {selectedConversation ? (
            <>
              <div className="message-list">
                <div className="message received">Hi there! How's the project going?</div>
                <div className="message sent">It's going great! I'm making good progress.</div>
                <div className="message received">Excellent! Let me know if you need anything.</div>
              </div>
              <form onSubmit={handleSendMessage} className="message-form">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type a message..."
                />
                <button type="submit">Send</button>
              </form>
            </>
          ) : (
            <p>Select a conversation to start chatting</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default Messages;

