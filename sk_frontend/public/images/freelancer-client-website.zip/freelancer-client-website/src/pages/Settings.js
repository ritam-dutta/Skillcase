import React, { useState } from 'react';
import './Settings.css';

function Settings() {
  const [personalInfo, setPersonalInfo] = useState({
    fullName: 'John Doe',
    email: 'john@example.com',
    phone: '123-456-7890',
    address: '123 Main St, Anytown, USA',
  });

  const [password, setPassword] = useState({
    current: '',
    new: '',
    confirm: '',
  });

  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    projectUpdates: true,
    newMessages: true,
  });

  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  const handlePersonalInfoChange = (e) => {
    const { name, value } = e.target;
    setPersonalInfo(prevInfo => ({ ...prevInfo, [name]: value }));
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPassword(prevPassword => ({ ...prevPassword, [name]: value }));
  };

  const handleNotificationChange = (e) => {
    const { name, checked } = e.target;
    setNotifications(prevNotifications => ({ ...prevNotifications, [name]: checked }));
  };

  const handlePersonalInfoSubmit = (e) => {
    e.preventDefault();
    console.log('Updating personal information:', personalInfo);
  };

  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    console.log('Changing password:', password);
  };

  const handleNotificationSubmit = (e) => {
    e.preventDefault();
    console.log('Updating notification settings:', notifications);
  };

  const handleTwoFactorToggle = () => {
    setTwoFactorEnabled(!twoFactorEnabled);
    console.log('Two-factor authentication:', !twoFactorEnabled ? 'Enabled' : 'Disabled');
  };

  return (
    <div className="settings">
      <h1>Settings</h1>
      <section className="section">
        <h2>Personal Information</h2>
        <form onSubmit={handlePersonalInfoSubmit}>
          <div className="form-group">
            <label htmlFor="fullName">Full Name</label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              value={personalInfo.fullName}
              onChange={handlePersonalInfoChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={personalInfo.email}
              onChange={handlePersonalInfoChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="phone">Phone</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={personalInfo.phone}
              onChange={handlePersonalInfoChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="address">Address</label>
            <textarea
              id="address"
              name="address"
              value={personalInfo.address}
              onChange={handlePersonalInfoChange}
            ></textarea>
          </div>
          <button type="submit">Update Personal Information</button>
        </form>
      </section>
      <section className="section">
        <h2>Change Password</h2>
        <form onSubmit={handlePasswordSubmit}>
          <div className="form-group">
            <label htmlFor="currentPassword">Current Password</label>
            <input
              type="password"
              id="currentPassword"
              name="current"
              value={password.current}
              onChange={handlePasswordChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="newPassword">New Password</label>
            <input
              type="password"
              id="newPassword"
              name="new"
              value={password.new}
              onChange={handlePasswordChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm New Password</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirm"
              value={password.confirm}
              onChange={handlePasswordChange}
            />
          </div>
          <button type="submit">Change Password</button>
        </form>
      </section>
      <section className="section">
        <h2>Notification Settings</h2>
        <form onSubmit={handleNotificationSubmit}>
          <div className="form-group">
            <label>
              <input
                type="checkbox"
                name="email"
                checked={notifications.email}
                onChange={handleNotificationChange}
              />
              Receive email notifications
            </label>
          </div>
          <div className="form-group">
            <label>
              <input
                type="checkbox"
                name="sms"
                checked={notifications.sms}
                onChange={handleNotificationChange}
              />
              Receive SMS notifications
            </label>
          </div>
          <div className="form-group">
            <label>
              <input
                type="checkbox"
                name="projectUpdates"
                checked={notifications.projectUpdates}
                onChange={handleNotificationChange}
              />
              Receive project update notifications
            </label>
          </div>
          <div className="form-group">
            <label>
              <input
                type="checkbox"
                name="newMessages"
                checked={notifications.newMessages}
                onChange={handleNotificationChange}
              />
              Receive new message notifications
            </label>
          </div>
          <button type="submit">Update Notification Settings</button>
        </form>
      </section>
      <section className="section">
        <h2>Two-Factor Authentication</h2>
        <div className="two-factor">
          <p>Two-factor authentication is currently {twoFactorEnabled ? 'enabled' : 'disabled'}.</p>
          <button onClick={handleTwoFactorToggle}>
            {twoFactorEnabled ? 'Disable' : 'Enable'} Two-Factor Authentication
          </button>
        </div>
      </section>
    </div>
  );
}

export default Settings;

