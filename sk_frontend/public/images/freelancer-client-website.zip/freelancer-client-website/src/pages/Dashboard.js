import React from 'react';
import './Dashboard.css';

function Dashboard() {
  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <div className="overview-cards">
        <div className="card">
          <h3>Completed Projects</h3>
          <p>15</p>
        </div>
        <div className="card">
          <h3>Ongoing Projects</h3>
          <p>3</p>
        </div>
        <div className="card">
          <h3>Pending Projects</h3>
          <p>2</p>
        </div>
        <div className="card">
          <h3>Total Earnings</h3>
          <p>$12,500</p>
        </div>
      </div>
      <div className="recent-activities">
        <h2>Recent Activities</h2>
        <ul>
          <li>Completed project "E-commerce Website Redesign"</li>
          <li>Received payment for "Mobile App Development"</li>
          <li>Started new project "Blog Theme Creation"</li>
        </ul>
      </div>
    </div>
  );
}

export default Dashboard;

