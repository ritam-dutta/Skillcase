import React, { useState } from 'react';
import './Skills.css';

function Skills() {
  const [skills, setSkills] = useState([
    { id: 1, name: 'React', endorsements: 15 },
    { id: 2, name: 'Node.js', endorsements: 12 },
    { id: 3, name: 'JavaScript', endorsements: 20 },
  ]);

  const [certifications, setCertifications] = useState([
    { id: 1, name: 'AWS Certified Developer', issuer: 'Amazon Web Services', date: '2023-01-15' },
    { id: 2, name: 'Google Analytics Certification', issuer: 'Google', date: '2022-11-30' },
  ]);

  const [newSkill, setNewSkill] = useState('');
  const [newCertification, setNewCertification] = useState({ name: '', issuer: '', date: '' });

  const handleAddSkill = (e) => {
    e.preventDefault();
    if (newSkill.trim()) {
      setSkills([...skills, { id: skills.length + 1, name: newSkill, endorsements: 0 }]);
      setNewSkill('');
    }
  };

  const handleAddCertification = (e) => {
    e.preventDefault();
    if (newCertification.name && newCertification.issuer && newCertification.date) {
      setCertifications([...certifications, { id: certifications.length + 1, ...newCertification }]);
      setNewCertification({ name: '', issuer: '', date: '' });
    }
  };

  return (
    <div className="skills">
      <h1>Skills & Certifications</h1>
      <div className="skills-section">
        <h2>Skills</h2>
        <ul className="skill-list">
          {skills.map((skill) => (
            <li key={skill.id} className="skill-item">
              {skill.name}
              <span className="endorsements">{skill.endorsements} endorsements</span>
            </li>
          ))}
        </ul>
        <form onSubmit={handleAddSkill} className="add-skill-form">
          <input
            type="text"
            value={newSkill}
            onChange={(e) => setNewSkill(e.target.value)}
            placeholder="Add a new skill"
          />
          <button type="submit">Add Skill</button>
        </form>
      </div>
      <div className="certifications-section">
        <h2>Certifications</h2>
        <ul className="certification-list">
          {certifications.map((cert) => (
            <li key={cert.id} className="certification-item">
              <h3>{cert.name}</h3>
              <p>Issuer: {cert.issuer}</p>
              <p>Date: {new Date(cert.date).toLocaleDateString()}</p>
            </li>
          ))}
        </ul>
        <form onSubmit={handleAddCertification} className="add-certification-form">
          <input
            type="text"
            value={newCertification.name}
            onChange={(e) => setNewCertification({...newCertification, name: e.target.value})}
            placeholder="Certification name"
          />
          <input
            type="text"
            value={newCertification.issuer}
            onChange={(e) => setNewCertification({...newCertification, issuer: e.target.value})}
            placeholder="Issuer"
          />
          <input
            type="date"
            value={newCertification.date}
            onChange={(e) => setNewCertification({...newCertification, date: e.target.value})}
          />
          <button type="submit">Add Certification</button>
        </form>
      </div>
    </div>
  );
}

export default Skills;

