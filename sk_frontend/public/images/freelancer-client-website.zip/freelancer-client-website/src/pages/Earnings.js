import React, { useState } from 'react';
import './Earnings.css';

function Earnings() {
  const [withdrawAmount, setWithdrawAmount] = useState('');

  const earnings = {
    availableBalance: 5000,
    pendingEarnings: 1500,
    totalEarnedThisMonth: 3500
  };

  const transactions = [
    { id: 1, date: '2023-05-15', description: 'Project completion: Website Redesign', amount: 2000, status: 'Completed' },
    { id: 2, date: '2023-05-10', description: 'Milestone payment: Mobile App Dev', amount: 1500, status: 'Pending' },
    { id: 3, date: '2023-05-05', description: 'Withdrawal', amount: -1000, status: 'Processed' },
  ];

  const handleWithdraw = (e) => {
    e.preventDefault();
    // In a real app, this would send the withdrawal request to the backend
    console.log('Withdrawing amount:', withdrawAmount);
    setWithdrawAmount('');
  };

  return (
    <div className="earnings">
      <h1>Earnings & Withdrawals</h1>
      <div className="summary">
        <div className="card">
          <h3>Available Balance</h3>
          <p>${earnings.availableBalance.toFixed(2)}</p>
        </div>
        <div className="card">
          <h3>Pending Earnings</h3>
          <p>${earnings.pendingEarnings.toFixed(2)}</p>
        </div>
        <div className="card">
          <h3>Total Earned (This Month)</h3>
          <p>${earnings.totalEarnedThisMonth.toFixed(2)}</p>
        </div>
      </div>
      <div className="withdraw-form">
        <h2>Withdraw Funds</h2>
        <form onSubmit={handleWithdraw}>
          <input
            type="number"
            value={withdrawAmount}
            onChange={(e) => setWithdrawAmount(e.target.value)}
            placeholder="Enter amount to withdraw"
            min="0"
            max={earnings.availableBalance}
            step="0.01"
          />
          <button type="submit">Withdraw</button>
        </form>
      </div>
      <div className="transaction-history">
        <h2>Transaction History</h2>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Description</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction) => (
              <tr key={transaction.id}>
                <td>{transaction.date}</td>
                <td>{transaction.description}</td>
                <td>${Math.abs(transaction.amount).toFixed(2)}</td>
                <td>{transaction.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Earnings;

