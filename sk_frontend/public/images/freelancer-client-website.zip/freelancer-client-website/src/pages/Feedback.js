import React, { useState } from 'react';
import './Feedback.css';

function Feedback() {
  const [reviews, setReviews] = useState([
    { id: 1, projectTitle: 'E-commerce Website', rating: 5, content: 'Excellent work! The website exceeded my expectations.', clientName: 'John Doe', reply: null },
    { id: 2, projectTitle: 'Mobile App Development', rating: 4, content: 'Great job overall. Could have been a bit faster.', clientName: 'Jane Smith', reply: 'Thank you for your feedback. I'll work on improving my speed for future projects.' },
    { id: 3, projectTitle: 'Logo Design', rating: 5, content: 'Perfect design! Captured our brand essence perfectly.', clientName: 'Bob Johnson', reply: null },
  ]);

  const handleReplySubmit = (reviewId, replyContent) => {
    setReviews(prevReviews => 
      prevReviews.map(review => 
        review.id === reviewId 
          ? { ...review, reply: replyContent } 
          : review
      )
    );
  };

  return (
    <div className="feedback">
      <h1>Feedback & Reviews</h1>
      <div className="review-list">
        {reviews.map((review) => (
          <div key={review.id} className="review-card">
            <div className="review-header">
              <h3>{review.projectTitle}</h3>
              <div className="rating">
                {[...Array(5)].map((_, index) => (
                  <span key={index} className={index < review.rating ? 'star-filled' : 'star-empty'}>
                    ★
                  </span>
                ))}
              </div>
            </div>
            <p className="review-content">{review.content}</p>
            <p className="reviewer-name">- {review.clientName}</p>
            {review.reply ? (
              <div className="reply">
                <h4>Your Reply:</h4>
                <p>{review.reply}</p>
              </div>
            ) : (
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleReplySubmit(review.id, e.target.reply.value);
                  e.target.reply.value = '';
                }}
                className="reply-form"
              >
                <textarea name="reply" placeholder="Write a reply..." required></textarea>
                <button type="submit">Send Reply</button>
              </form>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Feedback;

